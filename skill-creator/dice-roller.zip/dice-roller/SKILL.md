---
name: dice-roller
description: This skill should be used when the user asks to roll a die or dice, play games involving dice, or needs random number generation between 1-6. Triggers include requests like "roll a die", "roll the dice", "throw a dice", or any game/decision-making scenario involving dice.
---

# Dice Roller

## Overview

This skill provides a simple dice rolling functionality that generates random numbers between 1 and 6, simulating a standard six-sided die (d6). Use this skill whenever the user requests to roll dice for games, decisions, or entertainment.

## How to Use

When the user asks to roll a die, use the bundled Python script to generate a random dice roll result. The script ensures true randomness and provides clear output.

### Basic Usage

For single dice rolls:
1. Execute `scripts/roll_dice.py` to generate a random number between 1-6
2. Display the result to the user in a friendly format

Example user requests:
- "掷骰子" / "Roll a die"
- "帮我掷个骰子" / "Roll the dice for me"
- "来个骰子" / "Give me a dice roll"

### Response Format

Always present the result in a clear, engaging way:
- Show the dice result visually (e.g., using emoji or text representation)
- State the number rolled
- Keep it simple and fun

Example response:
```
🎲 骰子点数: 4
```

or

```
🎲 Dice Roll: 4
```

## Technical Details

The skill uses `scripts/roll_dice.py` which:
- Generates cryptographically secure random numbers using Python's `random.SystemRandom()`
- Returns a single integer between 1 and 6 (inclusive)
- Can be extended to support multiple dice or different die types if needed

## Resources

### scripts/

This skill includes a Python script that generates random dice rolls:
- `roll_dice.py` - Main dice rolling logic with secure random generation
