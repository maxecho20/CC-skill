#!/usr/bin/env python3
"""
Dice Roller Script

Generates a random dice roll (1-6) using secure random number generation.
This script simulates rolling a standard six-sided die (d6).

Usage:
    python3 roll_dice.py

Output:
    A single integer between 1 and 6 (inclusive)
"""

import random


def roll_dice():
    """
    Roll a standard six-sided die (d6).

    Returns:
        int: Random number between 1 and 6 (inclusive)
    """
    # Use SystemRandom for cryptographically secure random numbers
    secure_random = random.SystemRandom()
    return secure_random.randint(1, 6)


def main():
    """Main entry point for the dice roller."""
    result = roll_dice()
    print(result)


if __name__ == "__main__":
    main()
